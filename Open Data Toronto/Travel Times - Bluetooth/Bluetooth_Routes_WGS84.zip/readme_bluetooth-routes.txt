Field Name	Description
resultId	Unique segment identifier representing a route between two point locations
normalDriv	Baseline travel time (derived from speed limit along route), in seconds
length_m	Length of segment, in metres